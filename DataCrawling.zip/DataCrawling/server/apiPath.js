//  api地址相对应的方法路径

module.exports = {
  '/pachong': 'pachong',
  '/get/status': 'getStatus',
  '/set/html': 'setHtml',
};
