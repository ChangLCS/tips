****************************************************

★感谢使用小米推送服务

★请访问小米推送主页：http://www.mipush.com ，了解更多

*****************************************************

获取更多帮助，

Android Client SDK文档：http://dev.xiaomi.com/doc/?p=544
iOS Client SDK文档：http://dev.xiaomi.com/doc/?p=2995
Unity接入指南（包含Android和iOS）：http://dev.xiaomi.com/doc/?p=6441
Server SDK文档：http://dev.xiaomi.com/doc/?p=533

***************************************************** 